package sample;

import java.sql.*;


class ModelOfMysql {

    /**
     * 说明：
     * 本文件用于连接mysql数据库
     * 以下为平时连接使用的连接信息
     * String URL = "jdbc:mysql://127.0.0.1:3306/company";
     * String USER = "root";
     * String PASSWORD = "123456";
     * <p>
     * 待做：
     * 设计为单例模式，放在在一个应用中产生多个数据库连接，浪费连接数。
     */

    private static Connection conn;
    private static String URL;
    private static String USER;
    private static String PASSWORD;


    ModelOfMysql(String URL, String USER, String PASSWORD) {
        ModelOfMysql.URL = URL;
        ModelOfMysql.USER = USER;
        ModelOfMysql.PASSWORD = PASSWORD;
    }

    static void connectMysql() throws Exception {
        //本模块用于连接数据库
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection(URL, USER, PASSWORD);
    }

    static int queryMysqlResults(String sqlInput) throws SQLException {
        //打印当前的查询数据库的结果
        System.out.println(sqlInput);
        Statement statement = conn.createStatement();
        ResultSet resultSet = statement.executeQuery(sqlInput);
        String columnValue = null;
        String columnName = null;
        if (resultSet.getRow() == 0) return 1;
        while (resultSet.next()) {
            ResultSetMetaData rsMeta = resultSet.getMetaData();
            int columnCount = rsMeta.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                columnValue = resultSet.getString(i);
                columnName = rsMeta.getColumnName(i);
                System.out.print(columnValue + ",");
            }
            System.out.println("");
        }
        statement.close();
        return 0;
    }

    static void quitSystem() throws Exception {
        //关闭系统的时候关闭当前的数据库链接
        conn.close();
    }
}
