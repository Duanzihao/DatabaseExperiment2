package sample;

import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

import java.text.MessageFormat;

public class Controller {

    public Button queryEnter;
    public TextField displayQuestion;
    public TextArea displaySQL;
    public TableView displayChart;
    public TextField optionOfUser;
    public ImageView interestingPic;
    public Button ExitButton;
    public Button aboutThisSystem;
    public Button Q1;
    public Button Q2;
    public Button Q3;
    public Button Q4;
    public Button Q5;
    public Button Q6;
    public Button Q7;
    public Button Q8;
    public Button Q9;
    public Button Q10;
    public Button Q11;
    public Button Q12;

    public Button closeButton;

    private int questionIndex = -1;//这个是作为点击的问题的标记

    public int getQuestionIndex() {
        return questionIndex;
    }

    public void clickQ1(MouseEvent mouseEvent) {
        Q1.setOnAction(event -> displayQuestion.setText("查询直接领导为%ENAME%的员工编号"));
        questionIndex = 1;
    }

    public void clickQ2(MouseEvent mouseEvent) {
        Q2.setOnAction(event -> displayQuestion.setText("查询项目所在地为%PLOCATION%的部门名称； "));
        questionIndex = 2;
    }

    public void clickQ3(MouseEvent mouseEvent) {
        Q3.setOnAction(event -> displayQuestion.setText("查询参与%PNAME%项目的所有工作人员的名字和居住地址"));
        questionIndex = 3;
    }

    public void clickQ4(MouseEvent mouseEvent) {
        Q4.setOnAction(event -> displayQuestion.setText("查询部门领导居住地在%ADDRESS%且工资不低于%SALARY%元的员 工姓名和居住地"));
        questionIndex = 4;
    }

    public void clickQ5(MouseEvent mouseEvent) {
        Q5.setOnAction(event -> displayQuestion.setText("查询没有参加项目编号为%PNO%的项目的员工姓名"));
        questionIndex = 5;
    }

    public void clickQ6(MouseEvent mouseEvent) {
        Q6.setOnAction(event -> displayQuestion.setText("查询部门领导工作日期在%MGRSTARTDATE%之后的部门名"));
        questionIndex = 6;
    }

    public void clickQ7(MouseEvent mouseEvent) {
        Q7.setOnAction(event -> displayQuestion.setText("查询总工作量大于%HOURS%小时的项目名称"));
        questionIndex = 7;
    }

    public void clickQ8(MouseEvent mouseEvent) {
        Q8.setOnAction(event -> displayQuestion.setText("查询员工平均工作时间低于%HOURS%的项目名称"));
        questionIndex = 8;
    }

    public void clickQ9(MouseEvent mouseEvent) {
        Q9.setOnAction(event -> displayQuestion.setText("查询至少参与了%N%个项目并且工作总时间超过%HOURS%小时的员 工名字"));
        questionIndex = 9;
    }

    public void clickQ10(MouseEvent mouseEvent) {
        Q10.setOnAction(event -> displayQuestion.setText("在 employee 表新增记录 2 条记录"));
        questionIndex = 10;
    }

    public void clickQ11(MouseEvent mouseEvent) {
        Q11.setOnAction(event -> displayQuestion.setText("将第 10 步新增的其中 1 条记录的地址改成“深圳市南山区西丽大学城哈工大（深圳）”"));
        questionIndex = 11;
    }

    public void clickQ12(MouseEvent mouseEvent) {
        Q12.setOnAction(event -> displayQuestion.setText("将第 10 步新增的 2 条记录中没有修改的那条记录删除"));
        questionIndex = 12;
    }

    //点击退出系统
    public void clickExitButton(MouseEvent mouseEvent) throws Exception {
        ModelOfMysql.quitSystem();

    }

    //敲击关于该系统
    public void clickAboutThisSystem(MouseEvent mouseEvent) throws Exception {
        ;
    }

    //
    public void clickqueryEnter(MouseEvent mouseEvent) throws Exception {
        //敲击提交选项
        //先得到用户想要搜索的信息
        System.out.println("==================================");
        System.out.println("选择问题:" + questionIndex);
        String userInput = optionOfUser.getText();
        String userQuery = "";
        //按照空格对用户的输入进行拆分
        String[] userInputSplit = userInput.split(" ");
        switch (questionIndex) {
            case 1:
                userQuery = String.format(
                        "select e1.essn " +
                                "from employee e1, employee e2 " +
                                "where e1.superssn = e2.essn " +
                                "and e2.ename = '%s';", userInputSplit[0]);
                break;
            case 2:
                userQuery = String.format(
                        "select dname " +
                                "from department, project " +
                                "where department.dno = project.dno " +
                                "and plocation = '%s'", userInputSplit[0]);
                break;
            case 3:
                userQuery = String.format(
                        "select ename, address " +
                                "from employee, project, works_on " +
                                "where works_on.essn = employee.essn " +
                                "and project.pno = works_on.pno " +
                                "and pname = '%s'", userInputSplit[0]);
                break;
            case 4:
                userQuery = String.format(
                        "select e1.ename, e1.address " +
                                "from employee e1, " +
                                "employee e2 " +
                                "where e1.superssn = e2.essn " +
                                "and e2.address like '%s' " +
                                "and e1.salary >= %s ;", '%' + userInputSplit[0] + '%', userInputSplit[1]);
                break;
            case 5:
                userQuery = MessageFormat.format(
                        "select ename " +
                                "from employee " +
                                "where " +
                                "ename not in " +
                                "(select ename " +
                                "from employee, " +
                                "project, " +
                                "works_on " +
                                "where employee.essn = works_on.essn " +
                                "and project.pno = works_on.pno " +
                                "and works_on.pno = '{0}')", userInputSplit[0]);
                break;
            case 6:
                userQuery = String.format(
                        "select pname " +
                                "from (select pno, sum(hours) as sum_hours " +
                                "      from works_on " +
                                "      group by pno) as result, " +
                                "      project " +
                                "where project.pno = result.pno " +
                                "  and result.sum_hours > %s;", userInputSplit[0]);
                break;
            case 7:
                userQuery = MessageFormat.format(
                        "select dname " +
                                "from department " +
                                "where mgrstartdate > '{0}'", userInputSplit[0]);
                break;
            case 8:
                userQuery = String.format(
                        "select pname " +
                                "from (select pname, sum_hours / person_count as hours_average " +
                                "      from (select pname, count(essn) as person_count, sum(hours) as sum_hours " +
                                "            from works_on, " +
                                "                 project " +
                                "            where works_on.pno = project.pno " +
                                "            group by pno) as sum_of_project_hours) as final_average " +
                                "where hours_average < %s;", userInputSplit[0]);
                break;
            case 9:
                userQuery = String.format(
                        "select ename " +
                                "from (select ename, " +
                                "             count(works_on.pno) as sum_of_projects, " +
                                "             sum(hours)          as sum_of_hours " +
                                "      from works_on, " +
                                "           employee, " +
                                "           project " +
                                "      where employee.essn = works_on.essn " +
                                "        and project.pno = works_on.pno " +
                                "      group by employee.essn) as final_result " +
                                "where sum_of_hours > %s " +
                                "  and sum_of_projects > %s", userInputSplit[0], userInputSplit[1]);
                break;
            case 10:
                //待做，先把上面九个查询语句进行验证
                ;
                break;
            case 11:
                //待做，先把上面九个查询语句进行验证
                ;
                break;
            case 12:
                //待做，先把上面九个查询语句进行验证
                ;
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + questionIndex);
        }

        //经过上面的步骤，现在用户要查询的信息已经搞好了
        //进行查询
        //对于当前数据库是否查询到结果做的一个标志位
        int isQuery = ModelOfMysql.queryMysqlResults(userQuery);
        System.out.println("isQuery:" + isQuery);
        //如果标志位被置为1，则说明没有查询到结果，这是需要弹出查询错误的窗口
        if (isQuery == 1) {
            NullResults.notFindData();
        }

    }
}