package sample;

import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class NullResults {

    //下面这句如果没有 new Stage()真的是要死人的......
    //我他妈从晚上12:30调代码到1:30,我感觉真的是要崩溃了......
    private static Stage errorWindow = new Stage();

    public Button closeButton;

    static void notFindData() throws Exception {

        //先生成一个Stage，用来显示未找到数据
        Parent errorPrompt = FXMLLoader.load(NullResults.class.getResource("NullResults.fxml"));
        errorWindow.setTitle("未找到数据");
        errorWindow.setScene(new Scene(errorPrompt, 399, 380));
        errorWindow.show();
    }


    public void closeStage(Event MouseEvent) {
        //用于关掉当前的窗口
        closeButton.setOnAction(event -> errorWindow.close());
    }

}
