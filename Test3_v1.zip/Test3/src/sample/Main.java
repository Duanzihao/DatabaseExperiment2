package sample;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

/**
 * 使用javaFX我是通过在youtube上跟着 thenewboston 这个博主进行学习的
 * 国内很多中文的教程其实写的真的是很垃圾的
 * 唉，被坑了两天的时间
 */

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("公司信息查询系统");
        primaryStage.setScene(new Scene(root, 590, 500));
        primaryStage.show();
    }


    public static void main(String[] args) throws Exception {
        //初始化链接数据库,这里到时候要搞成给出窗口的连接
        String URL = "jdbc:mysql://127.0.0.1:3306/company";
        String USER = "root";
        String PASSWORD = "123456";
        new ModelOfMysql(URL, USER, PASSWORD);
        ModelOfMysql.connectMysql();
        //启动窗口
        launch(args);
    }
}

